# from onpolicy.envs.gridworld.gym_minigrid.envs.empty import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.doorkey import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.multiroom import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.fetch import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.gotoobject import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.gotodoor import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.putnear import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.lockedroom import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.keycorridor import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.unlock import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.unlockpickup import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.blockedunlockpickup import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.playground_v0 import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.redbluedoors import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.obstructedmaze import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.memory import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.fourrooms import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.crossing import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.lavagap import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.dynamicobstacles import *
# from onpolicy.envs.gridworld.gym_minigrid.envs.distshift import *
from onpolicy.envs.gridworld.gym_minigrid.envs.human import *
from onpolicy.envs.gridworld.gym_minigrid.envs.multiexploration import *
