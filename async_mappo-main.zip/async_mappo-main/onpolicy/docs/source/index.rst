.. onpolicy documentation master file, created by
   sphinx-quickstart on Sun Dec  6 23:54:05 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to onpolicy's documentation!
====================================

.. image:: full.gif

.. include:: setup.rst

.. include:: quickstart.rst

.. toctree::
   :maxdepth: 2
   :caption: API Reference:

   api/modules.rst



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
